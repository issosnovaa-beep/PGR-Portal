-- ПГР Mini App: выполнить целиком в Supabase -> SQL Editor.
-- ВАЖНО: роли выдаёт только доверенный администратор через SQL/Dashboard.
-- Не помещайте service_role key в HTML.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default 'Участник',
  role text not null default 'member'
    check (role in ('chairman','general_secretary','secretariat','admin','member')),
  created_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 150),
  body text not null check (char_length(body) between 1 and 5000),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.meetings (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 150),
  starts_at timestamptz not null,
  place text,
  description text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  url text not null check (url like 'https://%'),
  description text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('proposal','secretariat','chairman')),
  title text not null check (char_length(title) between 1 and 120),
  body text not null check (char_length(body) between 1 and 4000),
  status text not null default 'new' check (status in ('new','in_review','resolved')),
  created_at timestamptz not null default now()
);

-- Автоматически создаём обычный профиль при создании пользователя Supabase Auth.
create or replace function public.create_pgr_profile()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles(id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), 'member')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_pgr on auth.users;
create trigger on_auth_user_created_pgr
after insert on auth.users
for each row execute procedure public.create_pgr_profile();

create or replace function public.pgr_is_staff()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid())
      and role in ('chairman','general_secretary','secretariat','admin')
  );
$$;

alter table public.profiles enable row level security;
alter table public.announcements enable row level security;
alter table public.meetings enable row level security;
alter table public.documents enable row level security;
alter table public.requests enable row level security;

-- Участники видят список профилей, но менять могут только собственное имя.
create policy "profiles read authenticated" on public.profiles
for select to authenticated using (true);
create policy "profiles update own name" on public.profiles
for update to authenticated using (id = (select auth.uid()))
with check (id = (select auth.uid()) and role = (select role from public.profiles p where p.id = (select auth.uid())));

create policy "announcements read" on public.announcements
for select to authenticated using (true);
create policy "announcements staff insert" on public.announcements
for insert to authenticated with check (public.pgr_is_staff() and created_by = (select auth.uid()));
create policy "announcements staff update" on public.announcements
for update to authenticated using (public.pgr_is_staff()) with check (public.pgr_is_staff());
create policy "announcements staff delete" on public.announcements
for delete to authenticated using (public.pgr_is_staff());

create policy "meetings read" on public.meetings
for select to authenticated using (true);
create policy "meetings staff insert" on public.meetings
for insert to authenticated with check (public.pgr_is_staff() and created_by = (select auth.uid()));
create policy "meetings staff update" on public.meetings
for update to authenticated using (public.pgr_is_staff()) with check (public.pgr_is_staff());
create policy "meetings staff delete" on public.meetings
for delete to authenticated using (public.pgr_is_staff());

create policy "documents read" on public.documents
for select to authenticated using (true);
create policy "documents staff insert" on public.documents
for insert to authenticated with check (public.pgr_is_staff() and created_by = (select auth.uid()));
create policy "documents staff update" on public.documents
for update to authenticated using (public.pgr_is_staff()) with check (public.pgr_is_staff());
create policy "documents staff delete" on public.documents
for delete to authenticated using (public.pgr_is_staff());

create policy "requests read own or staff" on public.requests
for select to authenticated using (user_id = (select auth.uid()) or public.pgr_is_staff());
create policy "requests insert own" on public.requests
for insert to authenticated with check (user_id = (select auth.uid()));
create policy "requests update staff" on public.requests
for update to authenticated using (public.pgr_is_staff()) with check (public.pgr_is_staff());

-- Пример: назначить председателя. Сначала зарегистрируй аккаунт в Supabase Auth,
-- затем подставь его email вместо chair@example.com и выполни запрос:
-- update public.profiles p set role='chairman'
-- from auth.users u where p.id=u.id and u.email='chair@example.com';

-- Для остальных должностей:
-- update public.profiles p set role='general_secretary'
-- from auth.users u where p.id=u.id and u.email='secretary@example.com';
