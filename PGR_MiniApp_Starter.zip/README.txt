ПГР Mini App — стартовый комплект

Файлы:
- index.html — интерфейс мини-приложения (адаптивный дизайн для телефона).
- supabase_setup.sql — таблицы, триггер создания профиля и политики безопасности.

Запуск:
1. Создайте проект в Supabase.
2. Откройте SQL Editor, вставьте весь supabase_setup.sql и нажмите Run.
3. В Project Settings -> API скопируйте Project URL и anon/public key.
4. В index.html найдите SUPABASE_URL и SUPABASE_ANON_KEY и вставьте значения.
5. В Supabase Authentication включите Email provider.
6. Создайте пользователя в Authentication -> Users (Invite user или Add user).
   При создании автоматически появится профиль с ролью member.
7. Назначьте нужные роли SQL-командой из конца supabase_setup.sql.
8. Разместите index.html на HTTPS-хостинге (например, GitHub Pages/Netlify/Vercel).
9. Чтобы открыть как Telegram Mini App, настройте Menu Button/Web App URL у BotFather на HTTPS-адрес сайта.

Важно:
- В HTML допустим только anon/public key. Никогда не вставляйте service_role key.
- В этой стартовой версии вход — email и пароль Supabase. Это не проверка Telegram initData.
- Подача в партию остаётся через государственный бот АНДИ; профиль в ПГР создаётся администратором после подтверждения членства.
- Пока нет автоматической синхронизации с государственным ботом: новых участников добавляет администратор, создавая им Auth-аккаунт.
- Перед реальным использованием проверьте RLS и доступы на тестовых аккаунтах. Не храните в этой системе реальные чувствительные данные.
